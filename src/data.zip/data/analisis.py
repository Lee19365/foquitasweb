# Análisis completo de comportamiento — Focas del Baikal
# Requisitos: pandas, numpy, matplotlib, sklearn, scipy, statsmodels
# Instala con: pip install pandas numpy matplotlib scikit-learn scipy statsmodels

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from scipy import stats
from statsmodels.tsa.seasonal import seasonal_decompose

# -------------------------
# 1) Ingestión y preprocesamiento
# -------------------------
ruta = "simulacion_focas_baikal_realista.csv"
df = pd.read_csv(ruta)

# Comprueba columnas esenciales
cols_esperadas = ['id_foca','timestamp','season','duracion_s','profundidad_m',
                  'temp_agua_C','temp_corpora_C','lat','lon','indice_actividad',
                  'fish_density','depth_prey_mean','peso_kg','BCI']
missing = [c for c in cols_esperadas if c not in df.columns]
if missing:
    raise ValueError(f"Faltan columnas en el CSV: {missing}")

# Parseo de timestamp con fechas tipo DD/MM/YYYY
df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True, errors='coerce')
df = df.sort_values(['id_foca','timestamp']).reset_index(drop=True)

# Crear columnas auxiliares
df['duracion_min'] = df['duracion_s'] / 60.0
df['date'] = df['timestamp'].dt.date
df['year_month'] = df['timestamp'].dt.to_period('M')

# Manejo de valores extremos no numéricos / NaNs (simples)
num_cols = ['duracion_s','profundidad_m','temp_agua_C','temp_corpora_C','indice_actividad','fish_density','peso_kg','BCI']
df[num_cols] = df[num_cols].apply(pd.to_numeric, errors='coerce')
df = df.dropna(subset=['timestamp','id_foca','profundidad_m','duracion_s']).reset_index(drop=True)

# Normalización simple (Z-score)
df['z_prof'] = stats.zscore(df['profundidad_m'].fillna(df['profundidad_m'].mean()))
df['z_dur'] = stats.zscore(df['duracion_s'].fillna(df['duracion_s'].mean()))
df['z_act'] = stats.zscore(df['indice_actividad'].fillna(df['indice_actividad'].mean()))
df['z_bci'] = stats.zscore(df['BCI'].fillna(df['BCI'].mean()))

# -------------------------
# 2) Estadísticas descriptivas
# -------------------------
desc_estacion = df.groupby('season')[['profundidad_m','duracion_s','duracion_min','indice_actividad','peso_kg','BCI']].agg(['mean','median','std','min','max'])
print("\nEstadísticas por estación (muestra):")
print(desc_estacion)

desc_individuo = df.groupby('id_foca')[['profundidad_m','duracion_s','indice_actividad','peso_kg','BCI']].agg(['mean','std','count'])
print("\nEstadísticas por individuo (primeras 6 filas):")
print(desc_individuo.head(6))

# -------------------------
# 3) Visualizaciones básicas
# -------------------------
plt.figure(figsize=(9,5))
plt.hist(df['profundidad_m'], bins=60)
plt.xlabel('Profundidad (m)')
plt.ylabel('Frecuencia')
plt.title('Distribución de profundidad (todas las inmersiones)')
plt.grid(True, alpha=0.3)
plt.show()

# Boxplots de profundidad por estación
plt.figure(figsize=(8,5))
seasons = ['Invierno','Primavera','Verano','Otoño']
data_box = [df.loc[df['season']==s,'profundidad_m'].dropna() for s in seasons]
plt.boxplot(data_box, labels=seasons)
plt.ylabel('Profundidad (m)')
plt.title('Profundidad por estación — Boxplot')
plt.grid(True, alpha=0.3)
plt.show()

# Scatter: profundidad vs duración (coloreado por estación)
plt.figure(figsize=(9,6))
for s in seasons:
    sub = df[df['season']==s]
    plt.scatter(sub['profundidad_m'], sub['duracion_min'], label=s, s=6)
plt.xlabel('Profundidad (m)')
plt.ylabel('Duración (min)')
plt.title('Profundidad vs Duración — por estación')
plt.legend()
plt.grid(True, alpha=0.25)
plt.show()

# Mapa simple
plt.figure(figsize=(8,6))
plt.scatter(df['lon'], df['lat'], s=(df['BCI'].clip(lower=0.5, upper=1.5)-0.3)*20, alpha=0.6)
plt.xlabel('Lon')
plt.ylabel('Lat')
plt.title('Posiciones de inmersiones (tamaño ∝ BCI)')
plt.grid(True, alpha=0.25)
plt.show()

# -------------------------
# 4) Agregaciones temporales
# -------------------------
dailies = df.set_index('timestamp').resample('D').size().rename('dives_per_day')
plt.figure(figsize=(12,4))
dailies.plot()
plt.ylabel('N° inmersiones (diario)')
plt.title('Inmersiones por día — todo el dataset')
plt.grid(True, alpha=0.25)
plt.show()

# Descomposición estacional
try:
    series = dailies.asfreq('D').fillna(0)
    decomposition = seasonal_decompose(series, model='additive', period=30)
    plt.figure(figsize=(12,8))
    decomposition.trend.plot(ax=plt.subplot(311)); plt.title('Tendencia')
    decomposition.seasonal.plot(ax=plt.subplot(312)); plt.title('Estacionalidad')
    decomposition.resid.plot(ax=plt.subplot(313)); plt.title('Residuales')
    plt.tight_layout()
    plt.show()
except Exception as e:
    print("Descomposición falló:", e)

# -------------------------
# 5) Anomalías
# -------------------------
df['anom_prof_z'] = (np.abs(df['z_prof']) > 3).astype(int)
df['anom_dur_z']  = (np.abs(df['z_dur']) > 3).astype(int)
df['anom_any_z'] = ((df['anom_prof_z'] + df['anom_dur_z']) > 0).astype(int)
print(f"\nAnomalías Z-score: profundidad={df['anom_prof_z'].sum()}, duración={df['anom_dur_z'].sum()}")

features = df[['profundidad_m','duracion_s','indice_actividad','temp_agua_C','BCI']].fillna(0)
iso = IsolationForest(n_estimators=200, contamination=0.01, random_state=42)
df['iso_score'] = iso.fit_predict(features)
df['anom_iso'] = (df['iso_score'] == -1).astype(int)
print(f"Anomalías IsolationForest: {df['anom_iso'].sum()}")

plt.figure(figsize=(9,6))
mask_norm = df['anom_iso']==0
mask_anom = df['anom_iso']==1
plt.scatter(df.loc[mask_norm,'profundidad_m'], df.loc[mask_norm,'duracion_min'], s=4, alpha=0.4)
plt.scatter(df.loc[mask_anom,'profundidad_m'], df.loc[mask_anom,'duracion_min'], s=20, marker='x')
plt.xlabel('Profundidad (m)')
plt.ylabel('Duración (min)')
plt.title('Anomalías (IsolationForest)')
plt.grid(True, alpha=0.25)
plt.show()

# -------------------------
# 6) Clustering
# -------------------------
X = df[['profundidad_m','duracion_s','indice_actividad']].fillna(0).values
kmeans = KMeans(n_clusters=3, random_state=42, n_init=20)
df['cluster'] = kmeans.fit_predict(X)

centroids = pd.DataFrame(kmeans.cluster_centers_, columns=['profundidad_m','duracion_s','indice_actividad'])
print("\nCentroides KMeans:")
print(centroids)

plt.figure(figsize=(9,6))
for c in sorted(df['cluster'].unique()):
    sub = df[df['cluster']==c]
    plt.scatter(sub['profundidad_m'], sub['duracion_min'], s=4, label=f'Cluster {c}')
plt.xlabel('Profundidad (m)')
plt.ylabel('Duración (min)')
plt.title('Clusters (KMeans)')
plt.legend()
plt.grid(True, alpha=0.25)
plt.show()

# -------------------------
# 7) Eventualidades prolongadas
# -------------------------
act_diaria = df.groupby(['id_foca', pd.Grouper(key='timestamp', freq='D')])['indice_actividad'].median().reset_index()
act_diaria['low_act'] = (act_diaria['indice_actividad'] < 0.5).astype(int)

racha_baja = act_diaria.groupby('id_foca')['low_act'].rolling(window=7, min_periods=1).sum().reset_index()
racha_baja = racha_baja.rename(columns={'low_act':'rolling_low_act_sum'})

foca_demo = df['id_foca'].iloc[0]
sub_act = act_diaria[act_diaria['id_foca']==foca_demo].set_index('timestamp')

plt.figure(figsize=(12,4))
plt.plot(sub_act.index, sub_act['indice_actividad'], marker='o')
plt.axhline(0.5, linestyle='--', label='umbral baja actividad')
plt.title(f'Actividad diaria — {foca_demo}')
plt.ylabel('Índice actividad')
plt.grid(True, alpha=0.25)
plt.legend()
plt.show()

# -------------------------
# 8) Correlaciones
# -------------------------
corr_vars = df[['profundidad_m','duracion_s','indice_actividad','fish_density','depth_prey_mean','peso_kg','BCI']].corr()
print("\nMatriz de correlación:")
print(corr_vars)

monthly = df.groupby('year_month')[['profundidad_m','fish_density']].mean().reset_index()
monthly['year_month'] = monthly['year_month'].dt.to_timestamp()
plt.figure(figsize=(10,4))
plt.plot(monthly['year_month'], monthly['profundidad_m'], label='Profundidad media')
plt.plot(monthly['year_month'], monthly['fish_density'], label='Fish density media')
plt.legend()
plt.grid(True, alpha=0.25)
plt.title('Profundidad media vs Densidad de peces (mensual)')
plt.show()

# -------------------------
# 9) Resumen automático
# -------------------------
n_records = len(df)
n_individuos = df['id_foca'].nunique()
n_anom_z = int(df['anom_any_z'].sum())
n_anom_iso = int(df['anom_iso'].sum())

summary = f"""
Resumen rápido:
- Registros: {n_records}
- Individuos: {n_individuos}
- Anomalías Z-score: {n_anom_z}
- Anomalías IsolationForest: {n_anom_iso}
- Clusters (KMeans=3), centroides:
{centroids.to_string(index=True)}
"""
print(summary)
