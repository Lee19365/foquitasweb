import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# CONFIGURACIÓN GENERAL
# ===============================
num_focas = 20
dias = 365
inmersiones_por_dia = 8
fecha_inicio = datetime(2024, 1, 1)
np.random.seed(42)

# ===============================
# ASIGNAR PESO INICIAL A CADA FOCA
pesos_iniciales = {
    f"F{str(i).zfill(2)}": np.random.uniform(55, 120)  # Pusa sibirica: rango realista
    for i in range(1, num_focas + 1)
}

def obtener_cambio_peso(estacion):
    """Cambios diarios promedio en el peso, según estación."""
    if estacion == "Invierno":
        return np.random.normal(-0.04, 0.02)  # pérdida por gasto energético
    elif estacion == "Primavera":
        return np.random.normal(0.05, 0.02)
    elif estacion == "Verano":
        return np.random.normal(0.08, 0.03)
    else:  # Otoño
        return np.random.normal(-0.02, 0.02)

# ===============================
# FUNCIONES AUXILIARES

def obtener_estacion(fecha):
    mes = fecha.month
    if mes in [12, 1, 2]:
        return "Invierno"
    elif mes in [3, 4, 5]:
        return "Primavera"
    elif mes in [6, 7, 8]:
        return "Verano"
    else:
        return "Otoño"

# GUARDAMOS EL PESO ACTUAL DE CADA FOCA
peso_actual = pesos_iniciales.copy()

def generar_inmersion(id_foca, fecha):
    estacion = obtener_estacion(fecha)

    # Actualizar peso antes de generar los datos del día
    cambio = obtener_cambio_peso(estacion)
    peso_actual[id_foca] = max(40, peso_actual[id_foca] + cambio)  # nunca <40 kg

    # Cálculo del BCI
    peso_inicial = pesos_iniciales[id_foca]
    bci = peso_actual[id_foca] / peso_inicial  

    # Timestamp
    hora = random.randint(0, 23)
    minuto = random.randint(0, 59)
    timestamp = fecha + timedelta(hours=hora, minutes=minuto)

    # Patrones por estación
    if estacion == "Invierno":
        duracion_s = np.random.normal(320, 80)
        profundidad_m = np.random.normal(100, 30)
        temp_agua = np.random.uniform(0, 2)
        actividad_base = np.random.uniform(2, 5)
    elif estacion == "Primavera":
        duracion_s = np.random.normal(360, 100)
        profundidad_m = np.random.normal(90, 25)
        temp_agua = np.random.uniform(1, 5)
        actividad_base = np.random.uniform(5, 8)
    elif estacion == "Verano":
        duracion_s = np.random.normal(400, 120)
        profundidad_m = np.random.normal(80, 40)
        temp_agua = np.random.uniform(4, 9)
        actividad_base = np.random.uniform(7, 10)
    else:  # Otoño
        duracion_s = np.random.normal(300, 80)
        profundidad_m = np.random.normal(70, 25)
        temp_agua = np.random.uniform(2, 7)
        actividad_base = np.random.uniform(4, 7)

    duracion_s = max(duracion_s, 20)
    profundidad_m = max(profundidad_m, 5)

    temp_corp = np.random.normal(37.2, 0.3)
    lat = np.random.uniform(52.5, 55.5)
    lon = np.random.uniform(104.5, 110.5)
    indice_actividad = max(actividad_base + np.random.normal(0, 1.5), 0)

    if estacion in ["Primavera", "Verano"]:
        fish_density = np.random.uniform(100, 300)
    else:
        fish_density = np.random.uniform(20, 150)

    depth_prey_mean = np.random.uniform(40, 120)

    return {
        "id_foca": id_foca,
        "timestamp": timestamp,
        "season": estacion,
        "duracion_s": round(duracion_s, 2),
        "profundidad_m": round(profundidad_m, 2),
        "temp_agua_C": round(temp_agua, 2),
        "temp_corpora_C": round(temp_corp, 2),
        "lat": round(lat, 3),
        "lon": round(lon, 3),
        "indice_actividad": round(indice_actividad, 2),
        "fish_density": round(fish_density, 2),
        "depth_prey_mean": round(depth_prey_mean, 2),

        # VARIABLES NUEVAS
        "peso_kg": round(peso_actual[id_foca], 2),
        "BCI": round(bci, 4)
    }

# ===============================
# GENERACIÓN DE DATOS
datos = []
for id_num in range(1, num_focas + 1):
    id_foca = f"F{str(id_num).zfill(2)}"
    for dia in range(dias):
        fecha = fecha_inicio + timedelta(days=dia)
        estacion = obtener_estacion(fecha)

        if estacion == "Invierno":
            inmersiones_dia = max(1, np.random.poisson(inmersiones_por_dia - 3))
        elif estacion in ["Primavera", "Verano"]:
            inmersiones_dia = max(1, np.random.poisson(inmersiones_por_dia + 2))
        else:
            inmersiones_dia = max(1, np.random.poisson(inmersiones_por_dia))

        for _ in range(inmersiones_dia):
            datos.append(generar_inmersion(id_foca, fecha))

df = pd.DataFrame(datos)

# ===============================
# ANOMALÍAS REALISTAS

# 1. Buceos extremadamente largos
for i in np.random.choice(df.index, size=15, replace=False):
    df.loc[i, "duracion_s"] *= np.random.uniform(1.8, 3.5)
    df.loc[i, "profundidad_m"] *= np.random.uniform(1.1, 1.5)

# 2. Actividad anormalmente baja
for i in np.random.choice(df.index, size=10, replace=False):
    df.loc[i, "indice_actividad"] *= np.random.uniform(0.1, 0.5)

# 3. Lecturas térmicas extrañas
for i in np.random.choice(df.index, size=8, replace=False):
    df.loc[i, "temp_agua_C"] += np.random.uniform(-5, 5)

# 4. Errores geográficos
for i in np.random.choice(df.index, size=8, replace=False):
    df.loc[i, "lat"] += np.random.uniform(-0.5, 0.5)
    df.loc[i, "lon"] += np.random.uniform(-0.5, 0.5)

# ===============================
# RESULTADOS
print(df.head())
print(df[['season','peso_kg','BCI']].head())

df.to_csv("simulacion_focas_baikal_realista.csv", index=False, encoding="utf-8-sig")
